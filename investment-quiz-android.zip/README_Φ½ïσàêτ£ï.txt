投資刷題 Android App 專案（完全離線版）

重要說明：這是可用 Android Studio 編譯成 APK 的完整專案原始碼，不是已編譯的 APK 檔。
目前產檔環境沒有 Android SDK / Gradle，因此無法在此直接編譯 APK；不會把專案 ZIP 假稱為 APK。

功能：
- 題庫內建於 app/src/main/assets/index.html（769 題，含 A-E 選項）
- 章節練習、隨機抽題、模擬考、交卷後公布答案
- 錯題重練、成績統計
- WebView 本機載入，不需要網路權限；題目及答題紀錄留在手機

如何產生 APK：
1. 在電腦安裝 Android Studio。
2. 解壓縮本專案資料夾。
3. Android Studio 選 Open，開啟此資料夾（含 settings.gradle）。
4. 等待 Gradle Sync 完成（第一次建置需網路下載 Android Gradle Plugin 與 SDK；這只影響建置，不影響安裝後離線使用）。
5. 選單 Build > Build Bundle(s) / APK(s) > Build APK(s)。
6. 成功後 APK 通常位於 app/build/outputs/apk/debug/app-debug.apk。
7. 將 APK 傳到 Android 手機安裝；若系統詢問，允許該來源安裝未知應用程式。

App 安裝後：
- 不需要網路即可刷題。
- 成績和錯題保存在該手機 App 的本機 WebView 儲存空間。
- 清除 App 資料或解除安裝可能會刪除紀錄。

不在電腦安裝 Android Studio 的替代方式（使用 GitHub 雲端編譯）：
1. 建立 GitHub 帳號與一個新的空白 Repository。
2. 將解壓後專案中的所有檔案上傳到 Repository（包含 .github 資料夾）。
3. 開啟 Repository 的 Actions，選擇「Build Android APK」，按 Run workflow。
4. 工作完成後進入該次執行頁面，在 Artifacts 下載 investment-quiz-debug-apk.zip，解壓後取得 app-debug.apk。
5. 將 APK 下載到 Android 手機安裝。

GitHub 雲端編譯需要在建置時連網；編譯完成並安裝後，App 本身不需要網路。
